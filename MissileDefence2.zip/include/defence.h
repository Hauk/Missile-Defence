/*
 * defence.h
 *
 *  Created on: 18 Aug 2010
 *      Author: hauk
 */

#ifndef DEFENCE_H_
#define DEFENCE_H_

using namespace std;

class Defence
{
	public:

	Defence();
	~Defence();

	protected:

	private:

};

#endif /* DEFENCE_H_ */
