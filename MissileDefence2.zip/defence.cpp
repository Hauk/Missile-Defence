/*
 * defence.cpp
 *
 *  Created on: 18 Aug 2010
 *      Author: hauk
 */

#include <iostream>

#include "include/defence.h"

using namespace std;

Defence::Defence()
{
	//Constructor
}

Defence::~Defence()
{
	//Destructor
}
